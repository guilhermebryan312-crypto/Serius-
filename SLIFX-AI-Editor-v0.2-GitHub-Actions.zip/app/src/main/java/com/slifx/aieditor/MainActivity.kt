package com.slifx.aieditor

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : Activity() {
    private lateinit var prompt: EditText
    private lateinit var status: TextView
    private lateinit var resolution: Spinner
    private lateinit var mode: Spinner
    private var chosenAudio: Uri? = null
    private var chosenClips = mutableListOf<Uri>()

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { chosenAudio = it; status.text = "Música selecionada. Preparado para planejar a edição." }
    }
    private val pickClips = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        chosenClips.clear()
        chosenClips.addAll(uris)
        status.text = "${uris.size} arquivo(s) de vídeo selecionado(s)."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 10, 20)
        window.navigationBarColor = Color.rgb(12, 10, 20)
        setContentView(screen())
    }

    private fun screen(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(20))
            setBackgroundColor(Color.rgb(12, 10, 20))
        }
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        body.addView(txt("SLIFX", 34, Color.WHITE, true))
        body.addView(txt("AUTONOMOUS AI EDITOR  •  BETA", 11, 0xFFB7A0FF.toInt(), true))
        body.addView(gap(22))
        body.addView(txt("Sua ideia. Sua edit. Automática.", 23, Color.WHITE, true))
        body.addView(txt("Descreva o personagem e o estilo. A IA deverá pesquisar fontes, planejar a montagem e preparar a renderização.", 14, 0xFFD0CDDA.toInt(), false))
        body.addView(gap(18))
        body.addView(txt("PROMPT DE EDIÇÃO", 12, 0xFFC8B6FF.toInt(), true))
        prompt = EditText(this).apply {
            hint = "Ex.: Subaru Natsuki, edit melancólica, música com drop forte, velocity, shakes sincronizados, tons azulados..."
            setHintTextColor(0xFF8D8998.toInt()); setTextColor(Color.WHITE)
            textSize = 15f; minLines = 4; gravity = Gravity.TOP
            setPadding(dp(13), dp(13), dp(13), dp(13))
            setBackgroundColor(0xFF211D30.toInt())
        }
        body.addView(prompt, LinearLayout.LayoutParams(-1, dp(130)))
        body.addView(gap(16))
        body.addView(txt("PESQUISA DE CENAS", 12, 0xFFC8B6FF.toInt(), true))
        body.addView(txt("A busca automática na internet será conectada a provedores de pesquisa e catálogos de mídia licenciada.", 13, 0xFFD0CDDA.toInt(), false))
        body.addView(btn("＋  Adicionar vídeos da galeria") { pickClips.launch(arrayOf("video/*")) })
        body.addView(btn("♫  Selecionar música") { pickAudio.launch(arrayOf("audio/*")) })
        body.addView(gap(12))
        body.addView(txt("RESOLUÇÃO DE SAÍDA", 12, 0xFFC8B6FF.toInt(), true))
        resolution = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("1080p Full HD", "1440p QHD", "4K — se o aparelho e as fontes suportarem"))
            setSelection(2)
        }
        body.addView(resolution)
        body.addView(gap(12))
        body.addView(txt("MODO DE INTELIGÊNCIA", 12, 0xFFC8B6FF.toInt(), true))
        mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Multi-IA (roteador de provedores)", "Gemini como planejador principal"))
            setSelection(0)
        }
        body.addView(mode)
        body.addView(gap(18))
        body.addView(btn("GERAR PLANO DE EDIÇÃO", true) {
            val p = prompt.text.toString().trim()
            status.text = if (p.isBlank()) "Escreva o que deseja editar primeiro."
            else "Prompt recebido. A interface está pronta; falta conectar pesquisa, provedores de IA e renderização para gerar o vídeo."
        })
        body.addView(gap(10))
        status = txt("Pronto. Nenhuma edição será renderizada até a integração do motor de vídeo.", 13, 0xFFC4C0D0.toInt(), false)
        body.addView(status)
        body.addView(gap(22))
        body.addView(txt("SLIFX AI Editor • versão 0.2.0 • protótipo de interface", 11, 0xFF888392.toInt(), false))
        return outer
    }

    private fun btn(label: String, primary: Boolean = false, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
        setBackgroundColor(if (primary) 0xFF7046E8.toInt() else 0xFF302941.toInt())
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(7) }
    }
    private fun txt(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(3), 0, dp(4))
    }
    private fun gap(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
