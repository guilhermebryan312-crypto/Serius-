# SLIFX AI Editor — Android project v0.2.0

Projeto Android inicial preparado para GitHub Actions. A interface aceita prompt, seleção opcional de mídia local, resolução pretendida e modo multi-IA.

## Estado real desta versão
**Ainda não é um editor autônomo completo.** Esta entrega compila a interface Android. Ela ainda não pesquisa clipes na web, não chama provedores de IA, não sincroniza batidas e não renderiza MP4. Os controles informam a configuração desejada, mas não fingem que uma edição foi gerada.

## Arquitetura necessária para o produto completo
1. **Backend seguro:** guardar chaves dos provedores; nunca colocar API keys no APK.
2. **Orquestrador multi-IA:** interface comum para Gemini e outros provedores, com fallback e limites de custo.
3. **Pesquisa de mídia:** pesquisar metadados e fontes autorizadas/licenciadas; validar termos de uso antes de baixar ou reutilizar cenas.
4. **Planejador de edição:** converter o prompt em um roteiro temporal estruturado (clipes, timestamps, transições, efeitos e áudio).
5. **Análise de áudio:** detectar BPM, batidas, drops e seções.
6. **Renderização:** FFmpeg ou motor equivalente, com exportação 9:16 e 4K apenas quando a fonte e o dispositivo suportarem.
7. **Fila de trabalhos:** progresso, cancelamento, repetição e retomada.
8. **Direitos e segurança:** evitar fontes que proíbam download/reutilização; música popular pode exigir licença para publicação.

## Como compilar
1. Crie um repositório GitHub e envie o conteúdo desta pasta para a branch `main`.
2. Abra **Actions** e execute `Build SLIFX AI Editor APK`.
3. Baixe o artefato `SLIFX-AI-Editor-APK` da execução concluída.

Requisitos: Java 17, Gradle 8.9, Android SDK 35.
